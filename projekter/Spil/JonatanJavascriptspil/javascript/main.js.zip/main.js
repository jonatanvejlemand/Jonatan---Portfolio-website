/* 
Main JavaScript 
Used for global scripts across the site
*/

/* 
Global Variable - set the variable to something you can use later.
The global variables can be used in every function below, so place them always on top. 
You can only have one variable with that name
Variables can't contain special characthers. 
*/

var app = document.getElementById('app'); // Target the HTML-tag <div id="app"> 
var buttonRed = document.getElementById('button-red') // Target HTML ID button-red
var itemBlue = true;


// Eventlistners is where you trigger something
// A list of some of the eventlistners: https://www.javatpoint.com/javascript-events
// They are used to nearly everything
// DOMContentLoaded triggers a call when the HMTL is loaded.
document.addEventListener('DOMContentLoaded', function() {
  app.classList.add('loaded') // is animated in CSS
})


// Add an Event listner to the button-red
// This triggers on click
document.addEventListener('click', function() {
    // change the color to red on click. 
    document.getElementById('bg-blue').style.background = 'red';

    // Use a function to swap between blue and red bg
    //blueRed()
})

// function
function blueRed() {
    // Local variable - bgBlue, can only be used inside this function.
    var bgBlue = document.getElementById('bg-blue');
    if(itemBlue === true) {
        bgBlue.style.background = 'red';
        itemBlue = false; 
    } else {
        bgBlue.style.background = 'blue';
        itemBlue = true; 
    }
}